<?php
namespace BooklyLocations\Backend\Modules\Locations;

use Bookly\Lib as BooklyLib;

class Page extends BooklyLib\Base\Component
{
    public static function render()
    {
        self::enqueueStyles( array(
            'bookly' => array( 'backend/resources/css/fontawesome-all.min.css' => array( 'bookly-backend-globals' ) ),
        ) );

        self::enqueueScripts( array(
            'module' => array(
                'js/locations.js' => array( 'bookly-backend-globals' ),
            ),
        ) );

        $staff_collection = BooklyLib\Entities\Staff::query()
            ->select( 'id, full_name, visibility' )
            ->indexBy( 'id' )
            ->fetchArray();
        foreach ( $staff_collection as &$staff ) {
            if ( $staff['visibility'] === 'archive' ) {
                $staff['full_name'] .= ' — ' . __( 'Archived', 'bookly' );
            }
        }

        $datatables = BooklyLib\Utils\Tables::getSettings( BooklyLib\Utils\Tables::LOCATIONS );

        wp_localize_script( 'bookly-locations.js', 'BooklyLocationsL10n', array(
            'new_location' => __( 'Add Location', 'bookly' ) . '…',
            'delete' => __( 'Delete', 'bookly' ) . '…',
            'order' => _x( 'Order', 'drag to reorder', 'bookly' ) . '…',
            'order_title' => __( 'Locations order', 'bookly' ),
            'order_hint' => __( 'Adjust the order of locations in your booking form', 'bookly' ),
            'search' => __( 'Quick search by name', 'bookly' ) . '…',
            'are_you_sure' => __( 'Are you sure?', 'bookly' ),
            'zeroRecords' => __( 'No locations found.', 'bookly' ),
            'staff' => array(
                'allSelected' => esc_attr__( 'All staff', 'bookly' ),
                'nothingSelected' => esc_attr__( 'No staff selected', 'bookly' ),
                'collection' => $staff_collection,
                'count' => count( $staff_collection ),
            ),
            'datatables' => $datatables,
        ) );

        self::renderTemplate( 'index', array(
            'staff_dropdown_data' => BooklyLib\Proxy\Pro::getStaffDataForDropDown( array() ),
            'staff_collection' => $staff_collection,
        ) );
    }

}
