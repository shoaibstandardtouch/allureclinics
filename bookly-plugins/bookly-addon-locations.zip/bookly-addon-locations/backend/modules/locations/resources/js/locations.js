jQuery(function ($) {
    'use strict';

    const table = 'locations';
    const $modal = $('#bookly-location-modal');
    const $name = $('#bookly-location-name', $modal);
    const $info = $('#bookly-location-info', $modal);
    const $staff = $('#bookly-js-staff', $modal);
    const $newTitle = $('#bookly-new-locations-title', $modal);
    const $editTitle = $('#bookly-edit-locations-title', $modal);
    const $saveButton = $('#bookly-location-save', $modal);

    // id of the location being edited; null => creating a new one.
    let editId = null;

    // Staff drop-down.
    $staff.booklyDropdown();

    /**
     * Init columns.
     */
    let columns = [];

    $.each(BooklyLocationsL10n.datatables[table].settings.columns, function (column, show) {
        switch (column) {
            case 'staff':
                columns.push({
                    data: 'staff',
                    render: function (data, type, row) {
                        if (data == 0) {
                            return BooklyLocationsL10n.staff.nothingSelected;
                        } else if (data == 1) {
                            return BooklyDatatables.escapeHtml(BooklyLocationsL10n.staff.collection[row.staff_id].full_name);
                        } else if (data == BooklyLocationsL10n.staff.count) {
                            return BooklyLocationsL10n.staff.allSelected;
                        }
                        return data + '/' + BooklyLocationsL10n.staff.count;
                    }
                });
                break;
            default:
                columns.push({ data: column, render: function (data) { return BooklyDatatables.escapeHtml(data); } });
                break;
        }
        columns[columns.length - 1].title = BooklyLocationsL10n.datatables[table].titles[column] || column;
        columns[columns.length - 1].name = column;
        columns[columns.length - 1].show = show;
    });

    /**
     * Init datatable.
     */
    let bt = BooklyDatatables.showForm('bookly-' + table + '-datatables', {
        serverSide: false,
        ajax: {
            url: ajaxurl,
            method: 'POST',
            data: function (d) {
                return $.extend({
                    action: 'bookly_locations_get_locations',
                    csrf_token: BooklyL10nGlobal.csrf_token
                }, d);
            }
        },
        columns: columns,
        tableSettings: Object.assign({}, BooklyLocationsL10n.datatables[table], {
            l10n: Object.assign({}, BooklyLocationsL10n.datatables.l10n, { zeroRecords: BooklyLocationsL10n.zeroRecords })
        }),
        edit: function (row) {
            openModal(row);
        },
        checked: function () {
            return [{
                label: BooklyLocationsL10n.delete,
                icon: 'trash',
                variant: 'destructive',
                click: function (selected) { deleteLocations(selected.map(function (r) { return r.id; })); }
            }];
        },
        searchFilter: {
            placeholder: BooklyLocationsL10n.search,
            name: 'filter[search]'
        },
        saveSettings: function (settings) {
            $.post(ajaxurl, Object.assign({
                action: 'bookly_update_table_settings',
                table: table,
                csrf_token: BooklyL10nGlobal.csrf_token
            }, settings));
        },
        topToolbar: [{
            label: BooklyLocationsL10n.order,
            icon: 'list-ordered',
            variant: 'outline',
            click: openReorder
        }, {
            id: 'bookly-new-location',
            label: BooklyLocationsL10n.new_location,
            icon: 'plus',
            variant: 'default',
            click: function () { openModal(null); }
        }]
    });

    /**
     * Open the reorder dialog. Items are taken in position order regardless of
     * the table's current column sort.
     */
    function openReorder() {
        const items = bt.getRows()
            .slice()
            .sort(function (a, b) { return a.position - b.position; })
            .map(function (row) {
                return { id: row.id, label: row.name || '' };
            });

        BooklyDatatables.showReorder({
            title: BooklyLocationsL10n.order_title,
            hint: BooklyLocationsL10n.order_hint,
            items: items,
            saveLabel: BooklyLocationsL10n.datatables.l10n.save,
            cancelLabel: BooklyLocationsL10n.datatables.l10n.cancel,
            onSave: function (orderedIds) {
                return $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    dataType: 'json',
                    data: booklySerialize.buildRequestData('bookly_locations_update_locations_position', { locations: orderedIds })
                }).then(function () { bt.reload(); });
            }
        });
    }

    /**
     * Open create/edit modal. row === null => new location.
     */
    function openModal(row) {
        editId = row ? row.id : null;
        $newTitle.toggle(!row);
        $editTitle.toggle(!!row);
        $name.val(row ? row.name : '');
        $info.val(row ? row.info : '');

        if (row) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'bookly_locations_get_location_lists',
                    csrf_token: BooklyL10nGlobal.csrf_token,
                    location_id: row.id
                },
                success: function (response) {
                    if (response.success) {
                        $staff.booklyDropdown('setSelected', response.data.staff_id);
                        $modal.booklyModal('show');
                    }
                }
            });
        } else {
            $staff.booklyDropdown('setSelected', []);
            $modal.booklyModal('show');
        }
    }

    /**
     * Save location.
     */
    $saveButton.on('click', function (e) {
        e.preventDefault();
        let data = booklySerialize.form($(this).closest('form')),
            ladda = Ladda.create(this, { timeout: 2000 });
        if (editId) {
            data.id = editId;
        }
        ladda.start();
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: booklySerialize.buildRequestData('bookly_locations_save_location', data),
            success: function (response) {
                ladda.stop();
                if (response.success) {
                    $modal.booklyModal('hide');
                    bt.reload();
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    /**
     * Delete the given locations by ids.
     */
    function deleteLocations(ids) {
        if (!confirm(BooklyLocationsL10n.are_you_sure)) {
            return;
        }
        bt.setLoading(true);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'bookly_locations_delete_locations',
                csrf_token: BooklyL10nGlobal.csrf_token,
                locations: ids
            },
            success: function (response) {
                if (response.success) {
                    bt.reload();
                } else {
                    bt.setLoading(false);
                    alert(response.data.message);
                }
            }
        });
    }
});
