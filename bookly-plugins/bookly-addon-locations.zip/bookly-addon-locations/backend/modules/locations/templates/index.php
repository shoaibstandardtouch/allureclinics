<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\PageHeader\Renderer as PageHeaderRenderer;
?>
<div id="bookly-tbs" class="wrap bookly-css-root bookly-main-page-wrap">
    <?php PageHeaderRenderer::render( $self::pageSlug(), __( 'Locations', 'bookly' ) ) ?>
    <div class="bookly:card">
        <div class="bookly:card-body">
            <div id="bookly-locations-datatables"></div>
        </div>
    </div>

    <?php include '_modal.php' ?>
</div>
