<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Inputs;
?>
<div class="col-md-3 my-2">
    <?php Inputs::renderCheckBox( __( 'Show waiting list slots', 'bookly' ), null, get_option( 'bookly_waiting_list_enabled' ), array( 'id' => 'bookly-show-waiting-list' ) ) ?>
</div>
